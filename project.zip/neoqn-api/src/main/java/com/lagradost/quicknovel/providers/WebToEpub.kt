@file:Suppress("unused", "UNUSED_PARAMETER", "RedundantSuspendModifier")

package com.lagradost.quicknovel.providers

import android.content.Context
import com.lagradost.quicknovel.ChapterData

/*
 * Compile-only stand-ins for NeoQN's built-in WebToEpub engine (v2.2.0).
 * The engine opens a page in a hidden WebView (which passes Cloudflare) and runs the
 * WebToEpub site parser bundled with the app to get the chapter list or chapter text.
 */

object WebToEpubMap {
    fun getParserForUrl(url: String): String? = throw IllegalStateException("NeoQN API stub")
}

object WebViewParserEngine {
    data class ParsedMetadata(
        val title: String,
        val author: String?,
        val cover: String?,
        val chapters: List<ChapterData>
    )

    suspend fun parseMetadata(context: Context, url: String, parserFile: String): ParsedMetadata =
        throw IllegalStateException("NeoQN API stub")

    suspend fun parseHtml(context: Context, url: String, parserFile: String): String =
        throw IllegalStateException("NeoQN API stub")
}
