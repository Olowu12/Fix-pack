@file:Suppress("unused", "UNUSED_PARAMETER")

package com.lagradost.quicknovel

import android.content.Context

/** Compile-only stand-in. Only the static app context is exposed to plugins. */
class BaseApplication {
    companion object {
        @JvmStatic
        var context: Context?
            get() = throw IllegalStateException("NeoQN API stub")
            set(value) = throw IllegalStateException("NeoQN API stub")
    }
}
