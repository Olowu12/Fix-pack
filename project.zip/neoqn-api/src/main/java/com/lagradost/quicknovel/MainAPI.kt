@file:Suppress("unused", "UNUSED_PARAMETER", "RedundantSuspendModifier")

package com.lagradost.quicknovel

import com.lagradost.nicehttp.Requests
import kotlinx.coroutines.sync.Mutex

/*
 * COMPILE-ONLY STAND-INS for NeoQN v2.2.0's provider API (app/src/main/java/.../MainAPI.kt).
 *
 * These are never packaged into the plugin. When NeoQN loads the plugin, its own copies of
 * these classes are used, so every name, parameter list and default value below must match
 * the app exactly. They were copied from the v2.2.0 source and checked against the
 * compiled v2.2.0 APK. Do not "improve" them.
 */

private fun stub(): Nothing = throw IllegalStateException("NeoQN API stub called outside NeoQN")

const val API_VERSION = 5

val app: Requests get() = stub()

abstract class MainAPI {
    var pluginContext: android.content.Context? = null
    open val name = "NONE"
    open val mainUrl = "NONE"
    open val lang = "en"

    open val rateLimitTime: Long = 0
    val hasRateLimit: Boolean get() = rateLimitTime > 0L
    val rateLimitMutex: Mutex = Mutex()

    open val usesCloudFlareKiller = false
    open val hasMainPage = false

    open val mainCategories: List<Pair<String, String>> = listOf()
    open val orderBys: List<Pair<String, String>> = listOf()
    open val tags: List<Pair<String, String>> = listOf()

    open val iconId: Int? = null
    open val iconBackgroundId: Int = 0
    open val iconFullScreen: Boolean = false

    open suspend fun loadMainPage(
        page: Int,
        mainCategory: String?,
        orderBy: String?,
        tag: String?,
    ): HeadMainPageResponse = stub()

    open val hasReviews: Boolean = false

    open suspend fun loadReviews(
        url: String,
        page: Int,
        showSpoilers: Boolean = false
    ): List<UserReview> = stub()

    open suspend fun search(query: String): List<SearchResponse>? = stub()
    open suspend fun load(url: String): LoadResponse? = stub()
    open suspend fun loadHtml(url: String): String? = stub()
}

class ErrorLoadingException(message: String? = null) : Exception(message)

fun MainAPI.fixUrlNull(url: String?): String? = stub()
fun MainAPI.fixUrl(url: String): String = stub()

data class HomePageList(val name: String, val list: List<SearchResponse>)

data class HeadMainPageResponse(val url: String, val list: List<SearchResponse>)

data class UserReview(
    val review: String,
    val reviewTitle: String?,
    val username: String?,
    val reviewDate: String?,
    val avatarUrl: String?,
    val rating: Int?,
    val ratings: List<Pair<Int, String>>?,
)

data class SearchResponse(
    val name: String,
    val url: String,
    var posterUrl: String? = null,
    var rating: Int? = null,
    var latestChapter: String? = null,
    val apiName: String,
    var posterHeaders: Map<String, String>? = null
)

fun MainAPI.newSearchResponse(
    name: String,
    url: String,
    fix: Boolean = true,
    initializer: SearchResponse.() -> Unit = { },
): SearchResponse = stub()

enum class ReleaseStatus(val resource: Int) {
    Ongoing(0),
    Completed(0),
    Paused(0),
    Dropped(0),
    Stubbed(0),
}

fun LoadResponse.setStatus(status: String?): Boolean = stub()

interface LoadResponse {
    val url: String
    val name: String
    var author: String?
    var posterUrl: String?
    var rating: Int?
    var peopleVoted: Int?
    var views: Int?
    var synopsis: String?
    var tags: List<String>?
    var status: ReleaseStatus?
    var posterHeaders: Map<String, String>?
    val apiName: String
    var related: List<SearchResponse>?
}

data class StreamResponse(
    override val url: String,
    override val name: String,
    val data: List<ChapterData>,
    override val apiName: String,
    override var author: String? = null,
    override var posterUrl: String? = null,
    override var rating: Int? = null,
    override var peopleVoted: Int? = null,
    override var views: Int? = null,
    override var synopsis: String? = null,
    override var tags: List<String>? = null,
    override var status: ReleaseStatus? = null,
    override var posterHeaders: Map<String, String>? = null,
    var nextChapter: ChapterData? = null,
    override var related: List<SearchResponse>? = null
) : LoadResponse

suspend fun MainAPI.newStreamResponse(
    name: String,
    url: String,
    data: List<ChapterData>,
    fix: Boolean = true,
    initializer: suspend StreamResponse.() -> Unit = { },
): StreamResponse = stub()

data class ChapterData(
    val name: String,
    val url: String,
    var dateOfRelease: String? = null,
    val views: Int? = null,
)

fun MainAPI.newChapterData(
    name: String,
    url: String,
    fix: Boolean = true,
    initializer: ChapterData.() -> Unit = { },
): ChapterData = stub()
