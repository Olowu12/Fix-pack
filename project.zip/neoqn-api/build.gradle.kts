// Compile-only stand-ins for NeoQN's provider API. Nothing from this module is put
// into the plugin APK: at runtime NeoQN v2.2.0 supplies the real classes.
plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lagradost.quicknovel.api"
    compileSdk = 35
    defaultConfig { minSdk = 24 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    api("com.github.Blatzar:NiceHttp:0.4.11")
    api("org.jsoup:jsoup:1.17.2")
    api("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.1")
}
