package com.neoqn.fixpack.providers

import com.lagradost.quicknovel.SearchResponse
import com.lagradost.quicknovel.app
import com.neoqn.fixpack.BROWSER_UA
import com.neoqn.fixpack.WebToEpubBridge
import com.neoqn.fixpack.urlEncode
import org.jsoup.nodes.Document

/*
 * Providers whose chapter list and chapter text come from NeoQN's built-in WebToEpub
 * engine (see WebToEpubBridge). Each one only defines how to search the site.
 * Search URLs and selectors come from the original providers, with fallbacks added.
 *
 * Names end in "(Fixed)" so they appear next to the old providers instead of fighting
 * them for the same name.
 */

// ── AllNovel / NovelBin / NovelFull share one site template ─────────────────────

abstract class TruyenTemplateBridge(
    override val name: String,
    override val mainUrl: String,
) : WebToEpubBridge() {
    override val itemSelectors = listOf(
        "#list-page .archive .list .row",
        "#list-page .list-novel .row",
        ".list-novel .row",
        ".list-truyen .row",
    )
    override val linkSelector: String? = ".truyen-title a, .novel-title a, h3.novel-title a, h3 a"
    override val novelUrlPattern: Regex? =
        Regex("""(/b/[^/?#]+/?$|/novel-book/[^/?#]+/?$|/[a-z0-9-]+\.html$)""")

    override suspend fun searchDocument(query: String): Document =
        app.get("$mainUrl/search?keyword=${query.urlEncode()}", referer = "$mainUrl/").document
}

class AllNovelFixed : TruyenTemplateBridge("AllNovel (Fixed)", "https://allnovel.org")
class NovelBinFixed : TruyenTemplateBridge("NovelBin (Fixed)", "https://novelbin.com")
class NovelFullFixed : TruyenTemplateBridge("NovelFull (Fixed)", "https://novelfull.com")

// ── LibRead / FreeWebNovel share one template ───────────────────────────────────

abstract class LibReadTemplateBridge(
    override val name: String,
    override val mainUrl: String,
    private val postPath: String,
) : WebToEpubBridge() {
    override val itemSelectors = listOf(
        "div.li-row > div.li > div.con",
        "div.li-row .con",
        "div.ul-list1 div.li",
    )
    override val linkSelector: String? = "div.txt > h3.tit > a, h3.tit a, .tit a"
    override val novelUrlPattern: Regex? = Regex("""/(novel|libread)/[^/?#]+/?$""")

    // The site has used both a POST form and a GET URL for search; try both.
    override suspend fun searchDocument(query: String): Document =
        app.post(
            "$mainUrl$postPath",
            data = mapOf("searchkey" to query),
            headers = mapOf("User-Agent" to BROWSER_UA, "Origin" to mainUrl),
            referer = "$mainUrl/",
        ).document

    override suspend fun search(query: String): List<SearchResponse> {
        val viaPost = super.search(query)
        if (viaPost.isNotEmpty()) return viaPost
        return try {
            parseResults(app.get("$mainUrl/search?keyword=${query.urlEncode()}", referer = "$mainUrl/").document)
        } catch (e: Exception) {
            emptyList()
        }
    }
}

class LibReadFixed : LibReadTemplateBridge("LibRead (Fixed)", "https://libread.com", "/search")
class FreeWebNovelFixed : LibReadTemplateBridge("FreeWebNovel (Fixed)", "https://freewebnovel.com", "/search/")

// ── Individual sites ────────────────────────────────────────────────────────────

class RoyalRoadFixed : WebToEpubBridge() {
    override val name = "Royal Road (Fixed)"
    override val mainUrl = "https://www.royalroad.com"
    override val itemSelectors = listOf("div.fiction-list-item", ".fiction-list .row")
    override val linkSelector: String? = "h2.fiction-title a, .fiction-title a"
    override val novelUrlPattern: Regex? = Regex("""/fiction/\d+/[^/?#]+/?$""")

    override suspend fun searchDocument(query: String): Document =
        app.get("$mainUrl/fictions/search?title=${query.urlEncode()}", referer = "$mainUrl/").document
}

class NovelHallFixed : WebToEpubBridge() {
    override val name = "Novel Hall (Fixed)"
    override val mainUrl = "https://novelhall.com"
    override val itemSelectors = listOf("table tr", ".section3 li", ".type li")
    override val linkSelector: String? = "td:nth-of-type(2) a, a[href]"
    override val novelUrlPattern: Regex? = Regex("""novelhall\.com/[a-z0-9-]+-\d+/?$""")

    override suspend fun searchDocument(query: String): Document =
        app.get("$mainUrl/index.php?s=so&module=book&keyword=${query.urlEncode()}", referer = "$mainUrl/").document
}

class LunoxScansFixed : WebToEpubBridge() {
    override val name = "Lunox Scans (Fixed)"
    override val mainUrl = "https://lunoxscans.com"
    override val itemSelectors = listOf("div.c-tabs-item__content", "div.page-item-detail", "div.row.c-tabs-item__content")
    override val linkSelector: String? = ".post-title a, h3 a, h4 a"
    override val novelUrlPattern: Regex? = Regex("""/(series|novel|manga)/[^/?#]+/?$""")

    override suspend fun searchDocument(query: String): Document =
        app.get("$mainUrl/?s=${query.urlEncode()}&post_type=wp-manga", referer = "$mainUrl/").document
}

class NovelLightFixed : WebToEpubBridge() {
    override val name = "Novel Light (Fixed)"
    override val mainUrl = "https://novelight.net"
    override val itemSelectors = listOf("div.manga-grid-list > a", ".manga-grid-list a.item")
    override val titleSelector: String? = "div.title, .title"
    override val novelUrlPattern: Regex? = Regex("""/book/[^/?#]+/?$""")

    override suspend fun searchDocument(query: String): Document =
        app.get("$mainUrl/catalog/?search=${query.urlEncode()}", referer = "$mainUrl/").document
}

class RanobesFixed : WebToEpubBridge() {
    override val name = "Ranobes (Fixed)"
    override val mainUrl = "https://ranobes.top"
    override val itemSelectors = listOf("div.short-cont", "article.block.story")
    override val linkSelector: String? = "h2.title > a, h2.title a, .title a"
    override val novelUrlPattern: Regex? = Regex("""/novels/\d+-[^/?#]+\.html$""")

    override suspend fun searchDocument(query: String): Document =
        app.post(
            "$mainUrl/index.php?do=search",
            data = mapOf(
                "do" to "search",
                "subaction" to "search",
                "search_start" to "0",
                "full_start" to "0",
                "result_from" to "1",
                "story" to query,
            ),
            referer = "$mainUrl/",
        ).document
}

class NoBadNovelFixed : WebToEpubBridge() {
    override val name = "NoBadNovel (Fixed)"
    override val mainUrl = "https://www.nobadnovel.com"
    override val itemSelectors = listOf(".grid > div")
    override val novelUrlPattern: Regex? = Regex("""/series/[^/?#]+/?$""")

    override suspend fun searchDocument(query: String): Document =
        app.get("$mainUrl/series?keyword=${query.urlEncode()}", referer = "$mainUrl/").document
}

class SyosetuFixed : WebToEpubBridge() {
    override val name = "Syosetu (Fixed)"
    override val mainUrl = "https://yomou.syosetu.com"
    override val lang = "ja"
    override val itemSelectors = listOf("div.searchkekka_box", ".p-search-novel", ".c-novel-list__item")
    override val linkSelector: String? = ".novel_h a, a[href*=ncode.syosetu.com]"
    override val novelUrlPattern: Regex? = Regex("""ncode\.syosetu\.com/n\w+/?$""")

    override suspend fun searchDocument(query: String): Document =
        app.get(
            "$mainUrl/search.php?search_type=novel&word=${query.urlEncode()}&order=hyoka",
            referer = "$mainUrl/",
        ).document
}
