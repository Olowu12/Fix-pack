package com.neoqn.fixpack

import com.lagradost.quicknovel.BaseApplication
import com.lagradost.quicknovel.ErrorLoadingException
import com.lagradost.quicknovel.LoadResponse
import com.lagradost.quicknovel.MainAPI
import com.lagradost.quicknovel.SearchResponse
import com.lagradost.quicknovel.fixUrl
import com.lagradost.quicknovel.newSearchResponse
import com.lagradost.quicknovel.newStreamResponse
import com.lagradost.quicknovel.providers.WebToEpubMap
import com.lagradost.quicknovel.providers.WebViewParserEngine
import org.jsoup.nodes.Document

/**
 * Base for providers that do their own search but hand chapter loading to NeoQN's
 * built-in WebToEpub engine.
 *
 * Why: "zero chapters" almost always means the site changed how it lists chapters
 * (new AJAX endpoint, pagination, JS rendering). The WebToEpub parsers bundled with
 * NeoQN are maintained upstream and run in a real WebView, which also gets through
 * Cloudflare. So chapter lists and chapter text come from the engine, and only search
 * (a short, simple page) is parsed here.
 *
 * Every step is wrapped so one broken page returns an empty result or a clear error
 * message instead of crashing the app.
 */
abstract class WebToEpubBridge : MainAPI() {

    /** Fetches the site's search results page for [query]. */
    protected abstract suspend fun searchDocument(query: String): Document?

    /** CSS selectors for one search result; the first selector that matches anything wins. */
    protected abstract val itemSelectors: List<String>

    /** Link to the novel inside a result. Null: the result itself, or its first link. */
    protected open val linkSelector: String? = null

    /** Title inside a result. Null: the link's title attribute, a heading, or the link text. */
    protected open val titleSelector: String? = null

    /**
     * Used only if no [itemSelectors] match (the site changed its search layout):
     * any link whose URL matches this is treated as a novel.
     */
    protected open val novelUrlPattern: Regex? = null

    override suspend fun search(query: String): List<SearchResponse> {
        val doc = try {
            searchDocument(query)
        } catch (e: Exception) {
            null
        } ?: return emptyList()
        return parseResults(doc)
    }

    protected fun parseResults(doc: Document): List<SearchResponse> {
        val results = LinkedHashMap<String, SearchResponse>()
        val items = itemSelectors.asSequence()
            .map { sel -> try { doc.select(sel) } catch (e: Exception) { null } }
            .firstOrNull { it != null && it.isNotEmpty() }

        if (items != null) {
            for (item in items) {
                try {
                    val link = linkSelector?.let { item.selectFirst(it) }
                        ?: (if (item.tagName() == "a" && item.hasAttr("href")) item else item.selectFirst("a[href]"))
                        ?: continue
                    val href = link.absUrl("href").ifBlank { link.attr("href") }
                    if (href.isBlank() || href.startsWith("javascript")) continue
                    val title = (titleSelector?.let { item.selectFirst(it)?.text() }
                        ?: link.attr("title").takeIf { it.isNotBlank() }
                        ?: item.selectFirst("h1, h2, h3, h4, h5")?.text()
                        ?: link.text()).trim()
                    if (title.isEmpty()) continue
                    val url = fixUrl(href)
                    if (url in results) continue
                    results[url] = newSearchResponse(name = title, url = url) {
                        posterUrl = item.imageUrl()
                    }
                } catch (e: Exception) {
                    // Skip a malformed result instead of failing the whole search.
                }
            }
        }

        val pattern = novelUrlPattern
        if (results.isEmpty() && pattern != null) {
            for (a in doc.select("a[href]")) {
                try {
                    val url = a.absUrl("href").substringBefore('#')
                    if (!pattern.containsMatchIn(url) || url.contains("chapter", ignoreCase = true)) continue
                    val title = a.attr("title").ifBlank { a.text() }.trim()
                    if (title.length < 2 || url in results) continue
                    results[url] = newSearchResponse(name = title, url = url, fix = false) {
                        posterUrl = a.imageUrl()
                    }
                } catch (e: Exception) {
                }
            }
        }
        return results.values.toList()
    }

    override suspend fun load(url: String): LoadResponse {
        val parser = WebToEpubMap.getParserForUrl(url)
            ?: throw ErrorLoadingException("$name: NeoQN has no WebToEpub parser for $url")
        val context = BaseApplication.context
            ?: throw ErrorLoadingException("$name: app not ready, try again")
        val meta = try {
            WebViewParserEngine.parseMetadata(context, url, parser)
        } catch (e: Exception) {
            throw ErrorLoadingException("$name: could not read the novel page (${e.message})")
        }
        val chapters = meta.chapters.filter { it.url.isNotBlank() }.distinctBy { it.url }
        if (chapters.isEmpty()) {
            throw ErrorLoadingException("$name: the page loaded but no chapters were found")
        }
        return newStreamResponse(name = meta.title, url = url, data = chapters, fix = false) {
            author = meta.author?.takeIf { it.isNotBlank() && it != "Unknown Author" }
            posterUrl = meta.cover
        }
    }

    override suspend fun loadHtml(url: String): String? {
        val parser = WebToEpubMap.getParserForUrl(url) ?: return null
        val context = BaseApplication.context ?: return null
        return try {
            WebViewParserEngine.parseHtml(context, url, parser).takeIf { it.isNotBlank() }
        } catch (e: Exception) {
            null
        }
    }
}
