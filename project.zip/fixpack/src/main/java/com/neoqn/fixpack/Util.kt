package com.neoqn.fixpack

import org.jsoup.nodes.Element
import java.net.URLEncoder

internal const val BROWSER_UA =
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

internal fun String.urlEncode(): String = URLEncoder.encode(this.trim(), "UTF-8")

/** Best cover image URL inside (or on) this element, handling lazy-loaded images. */
internal fun Element.imageUrl(): String? {
    val img = if (tagName() == "img") this else selectFirst("img") ?: return null
    for (attr in listOf("data-src", "data-lazy-src", "data-original", "data-cfsrc", "src")) {
        val value = img.absUrl(attr).ifBlank { img.attr(attr) }.trim()
        if (value.isNotEmpty() && !value.startsWith("data:")) return value
    }
    return null
}

/** Removes ads, scripts and the junk tags some sites inject to break scrapers. */
internal fun Element.cleanChapter(): Element {
    select("script, style, noscript, iframe, ins, form, button, .ads, .ad, .adsbygoogle, [class*=advert], [id*=advert]").remove()
    allElements
        .filter { it !== this && !it.tag().isKnownTag }
        .forEach { it.remove() }
    return this
}
