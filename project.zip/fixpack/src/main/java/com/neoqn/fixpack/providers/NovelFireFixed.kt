package com.neoqn.fixpack.providers

import com.lagradost.quicknovel.BaseApplication
import com.lagradost.quicknovel.ChapterData
import com.lagradost.quicknovel.ErrorLoadingException
import com.lagradost.quicknovel.HeadMainPageResponse
import com.lagradost.quicknovel.LoadResponse
import com.lagradost.quicknovel.MainAPI
import com.lagradost.quicknovel.SearchResponse
import com.lagradost.quicknovel.app
import com.lagradost.quicknovel.newSearchResponse
import com.lagradost.quicknovel.newStreamResponse
import com.lagradost.quicknovel.providers.WebToEpubMap
import com.lagradost.quicknovel.providers.WebViewParserEngine
import com.lagradost.quicknovel.setStatus
import com.neoqn.fixpack.cleanChapter
import com.neoqn.fixpack.imageUrl
import com.neoqn.fixpack.urlEncode
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.net.URI

/**
 * NovelFire, rewritten.
 *
 * The old provider POSTed the novel slug to /listChapterDataAjax and parsed an HTML list.
 * NovelFire now puts a signed /listChapterDataAjax URL inside a script on the
 * /chapters page and answers with JSON (a DataTables feed). That change is why the old
 * provider showed no chapters.
 *
 * Chapter list, in order of preference:
 *   1. the JSON feed (one request, every chapter)
 *   2. the paginated HTML list at /chapters?page=N
 *   3. NeoQN's built-in WebToEpub engine (WebView, gets through Cloudflare)
 */
class NovelFireFixed : MainAPI() {
    override val name = "NovelFire (Fixed)"
    override val mainUrl = "https://novelfire.net"
    override val hasMainPage = true
    override val rateLimitTime = 150L

    override val mainCategories = listOf(
        "All" to "status-all",
        "Completed" to "status-completed",
        "Ongoing" to "status-ongoing",
    )
    override val orderBys = listOf(
        "Popular" to "sort-popular",
        "New" to "sort-new",
        "Updates" to "sort-latest-release",
    )
    override val tags = listOf("All" to "all") + listOf(
        "Action", "Adult", "Adventure", "Anime", "Arts", "Comedy", "Drama", "Eastern", "Ecchi",
        "Fan-fiction", "Fantasy", "Game", "Gender-bender", "Harem", "Historical", "Horror",
        "Isekai", "Josei", "Lgbt", "Magic", "Magical-realism", "Manhua", "Martial-arts", "Mature",
        "Mecha", "Military", "Modern-life", "Movies", "Mystery", "Other", "Psychological",
        "Realistic-fiction", "Reincarnation", "Romance", "School-life", "Sci-fi", "Seinen",
        "Shoujo", "Shoujo-ai", "Shounen", "Shounen-ai", "Slice-of-life", "Smut", "Sports",
        "Supernatural", "System", "Tragedy", "Urban", "Urban-life", "Video-games", "War",
        "Wuxia", "Xianxia", "Xuanhuan", "Yaoi", "Yuri",
    ).map { it to it.lowercase() }

    private val ajaxHeaders = mapOf(
        "X-Requested-With" to "XMLHttpRequest",
        "Accept" to "application/json, text/javascript, */*; q=0.01",
    )

    // ── Browse & search ──────────────────────────────────────────────────────────

    override suspend fun loadMainPage(
        page: Int,
        mainCategory: String?,
        orderBy: String?,
        tag: String?,
    ): HeadMainPageResponse {
        val url = "$mainUrl/genre-${tag ?: "all"}/${orderBy ?: "sort-popular"}/" +
            "${mainCategory ?: "status-all"}/all-novel?page=$page"
        val list = try {
            parseNovelList(app.get(url, referer = "$mainUrl/").document)
        } catch (e: Exception) {
            emptyList()
        }
        return HeadMainPageResponse(url, list)
    }

    override suspend fun search(query: String): List<SearchResponse> {
        return try {
            parseNovelList(app.get("$mainUrl/search?keyword=${query.urlEncode()}", referer = "$mainUrl/").document)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun parseNovelList(doc: Document): List<SearchResponse> {
        val out = LinkedHashMap<String, SearchResponse>()
        for (item in doc.select("li.novel-item, div.novel-item")) {
            try {
                val link = item.selectFirst("a[href*=/book/]") ?: item.selectFirst("a[href]") ?: continue
                val url = bookUrl(link.absUrl("href")) ?: continue
                val title = (link.attr("title").takeIf { it.isNotBlank() }
                    ?: item.selectFirst("h4.novel-title, .novel-title, h4, h3")?.text()
                    ?: link.text()).trim()
                if (title.isEmpty() || url in out) continue
                out[url] = newSearchResponse(name = title, url = url, fix = false) { posterUrl = item.imageUrl() }
            } catch (e: Exception) {
            }
        }
        if (out.isEmpty()) {
            // Layout changed: fall back to any link that looks like a novel page.
            for (a in doc.select("a[href*=/book/]")) {
                val url = bookUrl(a.absUrl("href")) ?: continue
                val title = a.attr("title").ifBlank { a.text() }.trim()
                if (title.length < 2 || url in out) continue
                out[url] = newSearchResponse(name = title, url = url, fix = false) { posterUrl = a.imageUrl() }
            }
        }
        return out.values.toList()
    }

    // ── Novel page ───────────────────────────────────────────────────────────────

    /** https://novelfire.net/book/<slug>[/anything] -> https://novelfire.net/book/<slug> */
    private fun bookUrl(url: String): String? {
        if (url.isBlank()) return null
        return Regex("""^(https?://[^/]+/book/[^/?#]+)""").find(url)?.groupValues?.get(1)
    }

    override suspend fun load(url: String): LoadResponse {
        val book = bookUrl(url) ?: url.substringBefore('?').trimEnd('/')
        val doc = try {
            app.get(book, referer = "$mainUrl/").document
        } catch (e: Exception) {
            throw ErrorLoadingException("NovelFire: could not open $book (${e.message})")
        }
        val title = doc.selectFirst("div.novel-info h1.novel-title, h1.novel-title, div.novel-info h1, h1")
            ?.text()?.trim()
        if (title.isNullOrEmpty()) {
            throw ErrorLoadingException("NovelFire: the novel page did not load (blocked or layout changed)")
        }

        val chapters = getChapters(book)
        if (chapters.isEmpty()) {
            throw ErrorLoadingException("NovelFire: found the novel but could not read its chapter list")
        }

        return newStreamResponse(name = title, url = book, data = chapters, fix = false) {
            posterUrl = doc.selectFirst("div.fixed-img img, figure.cover img, .novel-cover img")?.imageUrl()
                ?: doc.selectFirst("meta[property=og:image]")?.attr("content")
            author = doc.selectFirst("div.author span[itemprop=author], span[itemprop=author], div.author a")
                ?.text()?.trim()?.takeIf { it.isNotEmpty() }
            synopsis = doc.selectFirst("div.summary div.content, div.summary .content")?.text()?.trim()
                ?: doc.selectFirst("meta[property=og:description]")?.attr("content")
            tags = doc.select("div.categories ul li a, div.categories a")
                .map { it.text().trim() }.filter { it.isNotEmpty() }.distinct()
            setStatus(statusOf(doc))
        }
    }

    private fun statusOf(doc: Document): String? {
        val stats = doc.select("div.header-stats span")
        return stats.firstOrNull { it.selectFirst("small")?.text()?.contains("Status", true) == true }
            ?.selectFirst("strong")?.text()
            ?: stats.mapNotNull { it.selectFirst("strong")?.text()?.trim() }
                .firstOrNull { it.equals("Ongoing", true) || it.equals("Completed", true) }
    }

    // ── Chapter list ─────────────────────────────────────────────────────────────

    private suspend fun getChapters(book: String): List<ChapterData> {
        val tocUrl = "$book/chapters"
        val toc = try {
            app.get(tocUrl, referer = book).document
        } catch (e: Exception) {
            null
        }
        if (toc != null) {
            try {
                val fromJson = chaptersFromJson(book, toc)
                if (fromJson.isNotEmpty()) return fromJson
            } catch (e: Exception) {
            }
            try {
                val fromHtml = chaptersFromHtml(tocUrl, toc)
                if (fromHtml.isNotEmpty()) return fromHtml
            } catch (e: Exception) {
            }
        }
        return try {
            chaptersFromEngine(book)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private suspend fun chaptersFromJson(book: String, toc: Document): List<ChapterData> {
        val script = toc.select("script").map { it.data() }
            .firstOrNull { it.contains("listChapterDataAjax") } ?: return emptyList()
        val path = Regex("""(/listChapterDataAjax[^"'`\s]*)""").find(script.replace("\\/", "/"))
            ?.groupValues?.get(1) ?: return emptyList()
        val origin = URI(book).let { "${it.scheme}://${it.host}" }
        val url = origin + path + (if ('?' in path) "&" else "?") + DATATABLE_QUERY

        val body = app.get(url, headers = ajaxHeaders, referer = "$book/chapters").text
        val rows = JSONObject(body).optJSONArray("data") ?: return emptyList()
        val chapters = ArrayList<ChapterData>(rows.length())
        for (i in 0 until rows.length()) {
            val row = rows.optJSONObject(i) ?: continue
            var number = row.opt("n_sort")?.toString()?.trim().orEmpty()
            if (number.isEmpty() || number == "null") continue
            if (number.endsWith(".0")) number = number.removeSuffix(".0")
            val title = Jsoup.parse(row.optString("title")).text().trim().ifEmpty { "Chapter $number" }
            chapters += ChapterData(name = title, url = "$book/chapter-$number")
        }
        return chapters.distinctBy { it.url }
    }

    private suspend fun chaptersFromHtml(tocUrl: String, first: Document): List<ChapterData> {
        val lastPage = first.select("ul.pagination li a[href]")
            .mapNotNull { Regex("""[?&]page=(\d+)""").find(it.attr("href"))?.groupValues?.get(1)?.toIntOrNull() }
            .maxOrNull()?.coerceAtMost(500) ?: 1

        val chapters = ArrayList<ChapterData>()
        chapters += chapterLinks(first)
        for (page in 2..lastPage) {
            val doc = try {
                app.get("$tocUrl?page=$page", referer = tocUrl).document
            } catch (e: Exception) {
                break
            }
            val part = chapterLinks(doc)
            if (part.isEmpty()) break
            chapters += part
        }
        return chapters.distinctBy { it.url }
    }

    private fun chapterLinks(doc: Document): List<ChapterData> =
        doc.select("ul.chapter-list a[href]").mapNotNull { a ->
            val url = a.absUrl("href")
            if (url.isBlank()) return@mapNotNull null
            val title = (a.selectFirst(".chapter-title")?.text()
                ?: a.attr("title").ifBlank { a.text() }).trim()
            ChapterData(name = title.ifEmpty { url.substringAfterLast('/') }, url = url)
        }

    private suspend fun chaptersFromEngine(book: String): List<ChapterData> {
        val parser = WebToEpubMap.getParserForUrl(book) ?: return emptyList()
        val context = BaseApplication.context ?: return emptyList()
        return WebViewParserEngine.parseMetadata(context, book, parser).chapters
            .filter { it.url.isNotBlank() }
    }

    // ── Chapter text ─────────────────────────────────────────────────────────────

    override suspend fun loadHtml(url: String): String? {
        try {
            val doc = app.get(url, referer = mainUrl).document
            val content = doc.selectFirst("div.chapter-content, div#content, #chapter-container")
            if (content != null) {
                content.cleanChapter()
                if (content.text().length > 50) return content.html()
            }
        } catch (e: Exception) {
        }
        // Blocked or changed: let the WebView engine try.
        return try {
            val parser = WebToEpubMap.getParserForUrl(url) ?: return null
            val context = BaseApplication.context ?: return null
            WebViewParserEngine.parseHtml(context, url, parser).takeIf { it.isNotBlank() }
        } catch (e: Exception) {
            null
        }
    }

    private companion object {
        // DataTables parameters NovelFire's own page sends (all chapters, ascending).
        const val DATATABLE_QUERY =
            "draw=1&columns%5B0%5D%5Bdata%5D=title&columns%5B0%5D%5Bname%5D=&columns%5B0%5D%5Bsearchable%5D=true" +
                "&columns%5B0%5D%5Borderable%5D=false&columns%5B0%5D%5Bsearch%5D%5Bvalue%5D=" +
                "&columns%5B0%5D%5Bsearch%5D%5Bregex%5D=false&columns%5B1%5D%5Bdata%5D=created_at" +
                "&columns%5B1%5D%5Bname%5D=&columns%5B1%5D%5Bsearchable%5D=true&columns%5B1%5D%5Borderable%5D=true" +
                "&columns%5B1%5D%5Bsearch%5D%5Bvalue%5D=&columns%5B1%5D%5Bsearch%5D%5Bregex%5D=false" +
                "&columns%5B2%5D%5Bdata%5D=n_sort&columns%5B2%5D%5Bname%5D=&columns%5B2%5D%5Bsearchable%5D=false" +
                "&columns%5B2%5D%5Borderable%5D=true&columns%5B2%5D%5Bsearch%5D%5Bvalue%5D=" +
                "&columns%5B2%5D%5Bsearch%5D%5Bregex%5D=false&order%5B0%5D%5Bcolumn%5D=2&order%5B0%5D%5Bdir%5D=asc" +
                "&start=0&length=-1&search%5Bvalue%5D=&search%5Bregex%5D=false"
    }
}
