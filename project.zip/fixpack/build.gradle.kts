plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.neoqn.fixpack"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.neoqn.fixpack"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            // Keep class and method names exactly as written: NeoQN loads providers by name.
            isMinifyEnabled = false
            // NeoQN only needs the APK to be signed, not signed by a particular key.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Provided by NeoQN at runtime; compile against it, never bundle it.
    compileOnly(project(":neoqn-api"))
    compileOnly("com.github.Blatzar:NiceHttp:0.4.11")
    compileOnly("org.jsoup:jsoup:1.17.2")
    compileOnly("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.1")
}
