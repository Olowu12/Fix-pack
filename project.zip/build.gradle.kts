// Versions match NeoQN v2.2.0 so the plugin links against the app cleanly.
plugins {
    id("com.android.application") version "8.7.0" apply false
    id("com.android.library") version "8.7.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
