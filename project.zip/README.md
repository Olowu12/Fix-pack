# NeoQN Fix Pack

Repaired providers for **NeoQN v2.2.0**, built on GitHub's servers by GitHub Actions.
You don't need a computer or Android Studio, just a free GitHub account.

## Set up (one time, from a phone browser)

1. Sign in at github.com and create a **new repository** (any name; Public is simplest).
2. In the repo, tap **Add file → Upload files** and upload **project.zip**. Commit.
3. Tap **Add file → Create new file**. For the name, type exactly
   `.github/workflows/build.yml`
   and paste in the contents of `build.yml`. Commit.
4. Open the **Actions** tab. A build starts by itself and takes about 5–8 minutes.
   If Actions is switched off, tap the button to enable workflows, then
   **Build NeoQN Fix Pack → Run workflow**.
5. When the run has a green tick, open **Releases** (on the repo's main page) and
   download **NeoQN_FixPack.apk**.

## Install in NeoQN

Settings → Advanced → **Import Provider APK** → pick `NeoQN_FixPack.apk`.
Do **not** install it with Android's package installer; it isn't an app.

Keep your old provider pack installed: the fixed providers are named
"… (Fixed)" and sit alongside the originals, so sites this pack doesn't cover keep working.
To move novels already in your library, use NeoQN's migrate feature.

## What's inside

| Provider | How it was fixed |
|---|---|
| NovelFire (Fixed) | Rewritten. Reads NovelFire's new JSON chapter feed, falls back to the paged HTML list, then to NeoQN's WebToEpub engine. Browse page included. |
| AllNovel, NovelBin, NovelFull, LibRead, FreeWebNovel, Royal Road, Novel Hall, Lunox Scans, Novel Light, Ranobes, NoBadNovel, Syosetu (all "Fixed") | Search is done by the provider; the chapter list and chapter text come from NeoQN's built-in WebToEpub engine, which uses maintained site parsers and a real WebView (gets through Cloudflare). |

Notes:
* Chapters loaded through the WebToEpub engine load one at a time in a hidden browser, so
  bulk downloads are slower than before.
* The "(Fixed)" providers have no browse/home page except NovelFire; use search, or paste a
  novel's link into NeoQN's search bar.

## If the build fails

Open the failed run in the Actions tab, tap the red step, and copy the error lines.

## Adding a provider

Copy one of the classes in `fixpack/src/main/java/com/neoqn/fixpack/providers/BridgeProviders.kt`,
change the name, address and search selectors, add its class name to
`fixpack/src/main/assets/plugin.json`, and push. The build runs again automatically.

`neoqn-api/` holds compile-only copies of NeoQN's provider API (taken from the v2.2.0 source).
They are not packaged into the APK. If a future NeoQN version changes that API, update them.
